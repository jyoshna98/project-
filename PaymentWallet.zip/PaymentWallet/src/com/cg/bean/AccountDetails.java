package com.cg.bean;
 
public class AccountDetails {
	private String account_holder;
	private int accountnumber;
	private String mobilenumber;
	private double balance;
	public String getAccount_holder() {
		return account_holder;
	}
	public void setAccount_holder(String account_holder) {
		this.account_holder = account_holder;
	}
	public int getAccountnumber() {
		return accountnumber;
	}
	public void setAccountnumber(int accountnumber) {
		this.accountnumber = accountnumber;
	}
	public String getMobilenumber() {
		return mobilenumber;
	}
	public void setMobilenumber(String mobilenumber) {
		this.mobilenumber = mobilenumber;
	}
	public double getBalance() {
		return balance;
	}
	public void setBalance(double balance) {
		this.balance = balance;
	}
	@Override
	public String toString() {
		return "AccountDetails [account_holder=" + account_holder + ", accountnumber=" + accountnumber
				+ ", mobilenumber=" + mobilenumber + ", balance=" + balance + "]";
	}
}
