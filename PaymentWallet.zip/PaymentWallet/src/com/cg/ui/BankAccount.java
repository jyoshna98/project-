package com.cg.ui;

import java.util.Scanner;

import com.cg.bean.AccountDetails;
import com.cg.service.Service;
import com.cg.service.ServiceAccount;

public class BankAccount {
	public static void main(String args[]) {
		Scanner sc=new Scanner(System.in);
		Service service = new ServiceAccount();
		System.out.println("Welcome!");
		System.out.println("-------------------------");
		while(true) {	
		System.out.println("Please select one option");
		System.out.println("1. Create Account");
		System.out.println("2. Show Balnace");
		System.out.println("3. Deposit");
		System.out.println("4. Withdraw");
		System.out.println("5. Fund Transfer");
		System.out.println("6. Print Transaction");
		System.out.println("7. Exit");
		
		int choice;
		choice = sc.nextInt();
		
	      switch(choice)
	      {
		 case 1:{
			 AccountDetails accountDetails = new AccountDetails(); 
		   System.out.println(" You are creating account now ");
		   System.out.println("Enter name");
		   accountDetails.setAccount_holder(sc.next());
		   System.out.println("Enter mobile number");
		   accountDetails.setMobilenumber(sc.next());
		   accountDetails.setAccountnumber((int) (Math.random()*1000));
		   System.out.println(" Account Number is "+ accountDetails.getAccountnumber());
		   System.out.println("  Enter account balance  ");
		   accountDetails.setBalance(sc.nextDouble());
		   System.out.println(accountDetails);
		   service.createAccount(accountDetails);
		   
		 }
		 break;
		   
		 case 2:{
			 System.out.println(" present account balance ");
			 System.out.println("Enter Account number");
			 int AccountNumber=sc.nextInt();
			 double presentBalance=service.showBalance(AccountNumber);
			 System.out.println("Present balance="+presentBalance);	
		  
		 }
		 break;
		 
		 
		 case 3:{
			 System.out.println(" you are deposting amount  ");
			 System.out.println("Enter Account number");
			 int  EnteredAccountnumber=sc.nextInt();
			 System.out.println("Enter amount to be deposited:");
			 double depositAmount=sc.nextDouble();
			 double totalBalance = service.depositBalance(EnteredAccountnumber,depositAmount);
			 System.out.println("Total available Balance ="+totalBalance);
		 }
		 break;
		   
		 case 4:{
	           System.out.println(" withdrawing amount ");
	           System.out.println("Enter Account number");
	           int  EnteredAccountnumber=sc.nextInt();
	           System.out.println("Enter amount to be withdrawn:");
	           double withdrawAmount=sc.nextDouble();
	           double totalBalance = service.withdrawBalance(EnteredAccountnumber,withdrawAmount);
	           System.out.println("Total available Balance ="+totalBalance);
			   
	      break;     
		 }
		 case 5:{
			 System.out.println(" Fund transfer");
			 System.out.println("Enter Your Account number");
			 int  userAccountnumber=sc.nextInt();
	         System.out.println("Enter Reciever Account number");
	         int  recieverAccountnumber=sc.nextInt();
	         System.out.println("Enter amount to be transfered");
	         double transferAmount= sc.nextDouble();
	         double availableBalance=service.fundTransfer(userAccountnumber,recieverAccountnumber,transferAmount);
	         System.out.println("Total available balance ="+availableBalance);
		 }
		   break;
		   
		 case 6:{
			 System.out.println("Printing trasactions"); 
		 }
			break;
			
		 case 7:{
			 System.exit(0);
		 } 
		 break;
		 
		 default:
		   System.out.println(" Invalid choice ");
	      }	
	}
	
	}

	}
