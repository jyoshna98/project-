package com.cg.dao;

import java.util.List;

import com.cg.bean.AccountDetails;

public interface IDao {
	public void setAccountList( AccountDetails accountDetails);
	public List<AccountDetails> getAccountDetails();
}
