package com.cg.dao;

import java.util.ArrayList;
import java.util.List;

import com.cg.bean.AccountDetails;

public class DaoAccount implements IDao {
	List<AccountDetails> accountlist = new ArrayList<AccountDetails>();
	@Override
	public void setAccountList(AccountDetails accountDetails) {
		accountlist.add(accountDetails);
		
	}

	@Override
	public List<AccountDetails> getAccountDetails() {
		System.out.println(accountlist);
		return accountlist;
	}

}
