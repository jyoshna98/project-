package com.cg.service;

import java.util.List;

import com.cg.bean.AccountDetails;
import com.cg.dao.DaoAccount;

public class ServiceAccount implements Service {
	DaoAccount daoAccount= new DaoAccount();

	@Override
	public void createAccount(AccountDetails accountDetails) {
		System.out.println(accountDetails);
		daoAccount.setAccountList(accountDetails);
		
	}

	@Override
	public double showBalance(int accountnumber) {
		List<AccountDetails> balList = daoAccount.getAccountDetails();
		 for(AccountDetails accountdetail:balList) {
			 if(accountdetail.getAccountnumber() == accountnumber) {
				 return accountdetail.getBalance();
	}
		 }
		 return 0;
	}
	@Override
	public double depositBalance(int enteredAccountnumber, double depositAmount) {
		 List<AccountDetails> balList = daoAccount.getAccountDetails();
		 for(AccountDetails accountdetail:balList) {
			 if(accountdetail.getAccountnumber() == enteredAccountnumber) {
				  accountdetail.setBalance(accountdetail.getBalance()+depositAmount);
				  return accountdetail.getBalance();
			 }
		 }
		 return 0;
	}

	@Override
	public double withdrawBalance(int enteredAccountnumber, double withdrawAmount) {
		List<AccountDetails> balList = daoAccount.getAccountDetails();
		 for(AccountDetails accountdetail:balList) {
			 if(accountdetail.getAccountnumber() == enteredAccountnumber) {
				  accountdetail.setBalance(accountdetail.getBalance()-withdrawAmount);
				  return accountdetail.getBalance();
			 }
		 }
		return 0;
	}

	@Override
	public double fundTransfer(int userAccountnumber, int recieverAccountnumber, double transferAmount) {
		double availableBalance=withdrawBalance(userAccountnumber,transferAmount);
        depositBalance(recieverAccountnumber, transferAmount);
		return availableBalance;
	}

}
