package com.cg.service;

import com.cg.bean.AccountDetails;

public interface Service {
	public void createAccount(AccountDetails accountDetails);
    public  double showBalance (int accountnumber);
    public double depositBalance(int enteredAccountnumber,double depositAmount);
    public double withdrawBalance(int enteredAccountnumber, double withdrawAmount);
    public double fundTransfer(int userAccountnumber, int recieverAccountnumber, double transferAmount);

}
